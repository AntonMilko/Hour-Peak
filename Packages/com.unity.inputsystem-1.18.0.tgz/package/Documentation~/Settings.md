---
uid: input-system-settings
---
# Input settings

To configure the Input System individually for each project, go to __Edit__ > __Project Settings…__ > __Input System Package__ from Unity's main menu.

This page describes each input setting in detail.

## Create Settings Asset

When you first view the input settings, they are not editable, and instead a button to __Create settings asset__ is displayed at the top of the input settings window.

![The Create settings asset button appears in the Input System Package window.](Images/CreateSettingsAsset.png){width="486" height="239"}

If you want to customise the input settings, you must first click this button, which creates a settings asset in your Project. Once your project contains a settings asset, the __Create settings asset__ is no longer displayed, and the settings fields become editable. Unity saves changes to your settings in the settings asset when you save the project.

If your project contains multiple settings assets, you can use the gear menu in the top-right corner of the window to choose which asset to use. You can also use this menu to create additional settings assets.


## Update Mode

This setting determines when the Input System processes input. The Input System can process input in one of three distinct ways:

|Type|Description|
|----|-----------|
|[`Process Events In Dynamic Update`](xref:UnityEngine.InputSystem.InputSettings.UpdateMode)|The Input System processes events at irregular intervals determined by the current framerate.|
|[`Process Events In Fixed Update`](xref:UnityEngine.InputSystem.InputSettings.UpdateMode)|The Input System processes events at fixed-length intervals. This corresponds to how [`MonoBehaviour.FixedUpdate`](https://docs.unity3d.com/ScriptReference/MonoBehaviour.FixedUpdate.html) operates. The length of each interval is determined by [`Time.fixedDeltaTime`](https://docs.unity3d.com/ScriptReference/Time-fixedDeltaTime.html).|
|[`Process Events Manually`](xref:UnityEngine.InputSystem.InputSettings.UpdateMode)|The Input System does not process events automatically. Instead, it processes them whenever you call [`InputSystem.Update()`](xref:UnityEngine.InputSystem.InputSystem.Update).|

> [!NOTE]
> The system performs two additional types of updates in the form of  [`InputUpdateType.BeforeRender`](xref:UnityEngine.InputSystem.LowLevel.InputUpdateType) (late update for XR tracking Devices) and [`InputUpdateType.Editor`](xref:UnityEngine.InputSystem.LowLevel.InputUpdateType) (for EditorWindows). Neither of these update types change how the application consumes input.

## Background Behavior

Background Behaviour determines what happens when [application focus](https://docs.unity3d.com/ScriptReference/Application-isFocused.html) is lost or regained, and how input behaves while the application is not in the foreground.

This setting is only relevant when "Run In Background" is enabled in the [Player Settings](https://docs.unity3d.com/Manual/class-PlayerSettings.html) for the project. This setting is only supported on some platforms. On platforms such as Android and iOS, your app will not run when it is not in the foreground.

In the Editor, "Run In Background" is considered to always be enabled as the player loop is kept running regardless of whether a Game View is focused or not. Also, in development players on desktop platforms, the setting is force-enabled during the build process.

> [!NOTE]
> In the editor, `Background Behavior` is further influenced by [`Play Mode Input Behavior`](#play-mode-input-behavior). See [Background and Focus Change Behavior](xref:input-system-devices#background-and-focus-change-behavior) for a detailed breakdown. In particular, which devices are considered as [`canRunInBackground`](xref:UnityEngine.InputSystem.InputDevice.canRunInBackground) partly depends on the [`Play Mode Input Behavior`](#play-mode-input-behavior) setting.

|Setting|Description|
|----|-----------|
|[`Reset And Disable Non Background Devices`](xref:UnityEngine.InputSystem.InputSettings.BackgroundBehavior.ResetAndDisableNonBackgroundDevices)|When focus is lost, perform a [soft reset](xref:UnityEngine.InputSystem.InputSystem.ResetDevice(UnityEngine.InputSystem.InputDevice,System.Boolean)) on all Devices that are not marked as [`canRunInBackground`](xref:UnityEngine.InputSystem.InputDevice.canRunInBackground) and also subsequently [disable](xref:UnityEngine.InputSystem.InputSystem.DisableDevice(UnityEngine.InputSystem.InputDevice,System.Boolean)) them. Does not affect Devices marked as being able to run in the background.<br><br>When focus is regained, [re-enable](xref:UnityEngine.InputSystem.InputSystem.EnableDevice(UnityEngine.InputSystem.InputDevice)) any Device that has been disabled and also issue a [sync request](xref:UnityEngine.InputSystem.InputSystem.TrySyncDevice(UnityEngine.InputSystem.InputDevice)) on these Devices in order to update their current state. If a Device is issued a sync request and does not respond to it, [soft-reset](xref:input-system-devices#device-resets) the Device.<br><br>This is the default setting.|
|[`Reset And Disable All Devices`](xref:UnityEngine.InputSystem.InputSettings.BackgroundBehavior.ResetAndDisableAllDevices)|When focus is lost, perform a [soft reset](xref:UnityEngine.InputSystem.InputSystem.ResetDevice(UnityEngine.InputSystem.InputDevice,System.Boolean)) on all Devices and also subsequently [disable](xref:UnityEngine.InputSystem.InputSystem.DisableDevice(UnityEngine.InputSystem.InputDevice,System.Boolean)) them.<br><br>When focus is regained, [re-enable](xref:UnityEngine.InputSystem.InputSystem.EnableDevice(UnityEngine.InputSystem.InputDevice)) all Devices and also issue a [sync request](xref:UnityEngine.InputSystem.InputSystem.TrySyncDevice(UnityEngine.InputSystem.InputDevice)) on each Device in order to update it to its current state. If a device does not respond to the sync request, [soft-reset](xref:input-system-devices#device-resets) it.|
|[`Ignore Focus`](xref:UnityEngine.InputSystem.InputSettings.BackgroundBehavior.IgnoreFocus)|Do nothing when focus is lost. When focus is regained, issue a [sync request](xref:input-system-devices#device-syncs) on all Devices.|

Focus behavior has implications for how [Actions](xref:input-system-actions) behave on focus changes. When a Device is reset, Actions bound to Controls on the device will be cancelled. This ensures, for example, that a user-controlled character in your game doesn't continue to move when focus is lost while the user is pressing one of the W, A, S or D keys. The cancellation happens in such a way that Actions are guaranteed to not trigger. That is, even if an Action is set to trigger on button release, it will not get triggered when a button is down and gets reset by a [Device reset](xref:input-system-devices#device-resets).

## Filter Noise On Current

[//]: # (REVIEW: should this be enabled by default)

This setting is disabled by default, and it's only relevant for apps that use the `.current` properties (such as [`Gamepad.current`](xref:UnityEngine.InputSystem.Gamepad.current)) in the API. If your app doesn't use these properties, leave this setting disabled. Otherwise, it adds needless overhead.

Whenever there is input on a Device, the system make the respective Device `.current`. For example, if a [`Gamepad`](xref:UnityEngine.InputSystem.Gamepad) receives new input, [`Gamepad.current`](xref:UnityEngine.InputSystem.Gamepad.current) is assigned to that gamepad.

Some Devices have noise in their input, and receive input even if nothing is interacting with them. For example, the PS4 DualShock controller generates a constant stream of input because of its built-in gyro. This means that if both an Xbox and a PS4 controller are connected, and the user is using the Xbox controller, the PS4 controller still pushes itself to the front continuously and makes itself current.

To counteract this, enable noise filtering. When this setting is enabled and your application receives input, the system determines whether the input comes from a Device that has noisy Controls ([`InputControl.noisy`](xref:UnityEngine.InputSystem.InputControl.noisy)). If it does, the system also determines whether the given input contains any state changes on a Control that isn't flagged as noisy. If so, that Device becomes current. Otherwise, your application still consumes the input, which is also visible on the Device, but the Device doesn't become current.

> [!NOTE]
> The system doesn't currently detect most forms of noise, but does detect those on gamepad sticks. This means that if the sticks wiggle a small amount but are still within deadzone limits, the Device still becomes current. This doesn't require actuating the sticks themselves. On most gamepads, there's a small tolerance within which the sticks move when the entire device moves.

## Compensate Orientation

If this setting is enabled, rotation values reported by [sensors](xref:input-system-sensors) are rotated around the Z axis as follows:

|Screen orientation|Effect on rotation values|
|---|---|
|[`ScreenOrientation.Portrait`](https://docs.unity3d.com/ScriptReference/ScreenOrientation.Portrait.html)|Values remain unchanged|
|[`ScreenOrientation.PortraitUpsideDown`](https://docs.unity3d.com/ScriptReference/ScreenOrientation.PortraitUpsideDown.html)|Values rotate by 180 degrees.|
|[`ScreenOrientation.LandscapeLeft`](https://docs.unity3d.com/ScriptReference/ScreenOrientation.LandscapeLeft.html)|Values rotate by 90 degrees.|
|[`ScreenOrientation.LandscapeRight`](https://docs.unity3d.com/ScriptReference/ScreenOrientation.LandscapeRight.html)|Values rotate by 270 degrees.|

This setting affects the following sensors:
* [`Gyroscope`](xref:UnityEngine.InputSystem.Gyroscope)
* [`GravitySensor`](xref:UnityEngine.InputSystem.GravitySensor)
* [`AttitudeSensor`](xref:UnityEngine.InputSystem.AttitudeSensor)
* [`Accelerometer`](xref:UnityEngine.InputSystem.Accelerometer)
* [`LinearAccelerationSensor`](xref:UnityEngine.InputSystem.LinearAccelerationSensor)

## Default value properties

|Property|Description|
|----|-----------|
|Default Deadzone Min|The default minimum value for [Stick Deadzone](ProcessorTypes.md#stick-deadzone) or [Axis Deadzone](ProcessorTypes.md#axis-deadzone) processors when no `min` value is explicitly set on the processor.|
|Default Deadzone Max|The default maximum value for [Stick Deadzone](ProcessorTypes.md#stick-deadzone) or [Axis Deadzone](ProcessorTypes.md#axis-deadzone) processors when no `max` value is explicitly set on the processor.|
|Default Button Press Point|The default [press point](xref:UnityEngine.InputSystem.Controls.ButtonControl.pressPointOrDefault) for [Button Controls](xref:UnityEngine.InputSystem.Controls.ButtonControl), and for various [Interactions](xref:input-system-interactions). For button Controls which have analog physics inputs (such as triggers on a gamepad), this configures how far they need to be held down for the system to consider them pressed.|
|Default Tap Time|Default duration for [Tap](xref:input-system-interactions#tap) and [MultiTap](xref:input-system-interactions#multitap) Interactions. Also used by by touchscreen Devices to distinguish taps from to new touches.|
|Default Slow Tap Time|Default duration for [SlowTap](xref:input-system-interactions#tap) Interactions.|
|Default Hold Time|Default duration for [Hold](xref:input-system-interactions#hold) Interactions.|
|Tap Radius|Maximum distance between two finger taps on a touchscreen Device for the system to consider this a tap of the same touch (as opposed to a new touch).|
|Multi Tap Delay Time|Default delay between taps for [MultiTap](xref:input-system-interactions#multitap) Interactions. Also used by touchscreen Devices to count multi-taps (See [`TouchControl.tapCount`](xref:UnityEngine.InputSystem.Controls.TouchControl.tapCount)).|

## Supported Devices

A Project usually supports a known set of input methods. For example, a mobile app might support only touch, and a console application might support only gamepads. A cross-platform application might support gamepads, mouse, and keyboard, but might not require XR Device support.

To narrow the options that the Editor UI presents to you, and to avoid creating input Devices and consuming input that your application won't use, you can restrict the set of supported Devices on a per-project basis.

If __Supported Devices__ is empty, no restrictions apply, which means that the Input System adds any Device that Unity recognizes and processes input for it. However, if __Support Devices__ contains one or more entries, the Input System only adds Devices that are of one of the listed types.

> [!NOTE]
> When the __Support Devices__ list changes, the system removes or re-adds Devices as needed. The system always keeps information about what Devices are available for potential, which means that no Device is permanently lost as long as it stays connected.

To add Devices to the list, click the Add (+) icon and choose a Device from the menu that appears.

### Override in Editor

In the Editor, you might want to use input Devices that the application doesn't support. For example, you might want to use a tablet in the Editor even if your application only supports gamepads.

To force the Editor to add all locally available Devices, even if they're not in the list of __Supported Devices__, open the [Input Debugger](xref:input-system-debugging) (menu: __Window > Analysis > Input Debugger__), and select __Options > Add Devices Not Listed in 'Supported Devices'__.

![The Input Debugger appears with Add Devices Not Listed In Supported Devices selected from the Options dropdown menu.](Images/AddDevicesNotListedInSupportedDevices.png){width="486" height="297"}

> [!NOTE]
> This setting is stored as a user setting, not a project setting. This means other users who open the project in their own Editor do not share the setting.

## Platform-specific settings

### iOS/tvOS

__Motion Usage__
  Governs access to the [pedometer](xref:input-system-sensors#stepcounter) on the device. If you enable this setting, the __Description__ field becomes editable. The text you enter into the Description field is added to your application's `Info.plist`.

### Editor

#### Play Mode Input Behavior

__Play Mode Input Behavior__ determines how input is handled in the Editor when in play mode. Unlike in built players, in the Unity Editor the input back-ends keep running for as long as the Editor is active, regardless of whether a Game View window is focused or not. This setting determines how input should behave when focus is __not__ on any Game View &ndash; and thus [`Application.isFocused`](https://docs.unity3d.com/ScriptReference/Application-isFocused.html) is false and the player considered to be running in the background.

|Setting|Description|
|-------|-----------|
|[`Pointers And Keyboards Respect Game View Focus`](xref:UnityEngine.InputSystem.InputSettings.EditorInputBehaviorInPlayMode.PointersAndKeyboardsRespectGameViewFocus)|Only [Pointer](xref:input-system-pointers) and [Keyboard](xref:input-system-keyboard) Devices require the Game View to be focused. Other Devices will route their input into the application regardless of Game View focus.<br><br>This setting essentially routes any input into the game that is, by default, not used to operate the Editor UI. So, Devices such as [gamepads](xref:input-system-gamepad) will go to the application at all times when in play mode whereas keyboard input, for example, will require explicitly giving focus to a Game View window.<br><br>This setting is the default.|
|[`All Devices Respect Game View Focus`](xref:UnityEngine.InputSystem.InputSettings.EditorInputBehaviorInPlayMode.AllDevicesRespectGameViewFocus)|Focus on a Game View is required for all Devices. When no Game View window is focused, all input goes to the editor and not to the application. This allows other EditorWindows to receive these inputs (from gamepads, for example).|
|[`All Device Input Always Goes To Game View`](xref:UnityEngine.InputSystem.InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView)|All editor input is disabled and input is considered to be exclusive to Game Views. Also, [`Background Behavior`](#background-behavior) is to be taken literally and executed like in players. Meaning, if in a certain situation, a Device is disabled in the player, it will get disabled in the editor as well.<br><br>This setting most closely aligns player behavior with editor behavior. Be aware, however, that no EditorWindows will be able to see input from Devices (this does not effect IMGUI and UITK input in the Editor in general as they do not consume input from the Input System).|

#### Input Action Property Drawer Mode

Determines how the Inspector window displays [`InputActionProperty`](xref:UnityEngine.InputSystem.InputActionProperty) fields.

This setting is not shown in the **Edit** &gt; **Project Settings** window, it is instead only available in the Debug mode of the Inspector window of an Input Settings asset. See the Unity Manual page for [working in the Inspector](https://docs.unity3d.com/Manual/InspectorOptions.html) under section Toggle Debug Mode.

|Setting|Description|
|-------|-----------|
|[`Compact`](xref:UnityEngine.InputSystem.InputSettings.InputActionPropertyDrawerMode.Compact)|Display the property in a compact format, using a minimal number of lines. Toggling between a reference to an input action in an asset and a directly serialized input action is done using a dropdown menu.|
|[`Multiline Effective`](xref:UnityEngine.InputSystem.InputSettings.InputActionPropertyDrawerMode.MultilineEffective)|Display the effective action underlying the property, using multiple lines. Toggling between a reference to an input action in an asset and a directly serialized input action is done using a property that is always visible. This mode could be useful if you want to see or revert prefab overrides and hide the field that is ignored.|
|[`Multiline Both`](xref:UnityEngine.InputSystem.InputSettings.InputActionPropertyDrawerMode.MultilineBoth)|Display both the input action and external reference underlying the property. Toggling between a reference to an input action in an asset and a directly serialized input action is done using a property that is always visible. This mode could be useful if you want to see both values of the property without needing to toggle Use Reference.|
